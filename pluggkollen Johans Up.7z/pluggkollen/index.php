<!DOCTYPE html>
<html>
  <head>
    <title> Studentchatten </title>
    <link rel="stylesheet" href="css/main.css" type="text/css" />
  </head>
  <body>
    <div class="header">
    <h1> Välkommen till pluggkollen! </h1>
  </div>
    <div class='loginlink'>
      <form name="loginbutton" method="POST" onsubmit="" action="login.php">
          <input type="submit" value="Logga in" id="loginbutton">
      </form>
    </div>
  </body>
</html>
